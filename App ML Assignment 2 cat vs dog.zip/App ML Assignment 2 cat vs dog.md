# Applied Machine Learning

# Assignment 2 : Image Classification

#### INTRODUCTION 

In this report we are going to tackle a binary image classification problem. The objective of this report is to build a machine learning model to classify image as either Cat or Dog. To demostrates above image classification , we will fit multiple models to classify image and will try to find out which model performs best among all the other models or correctly identifies animal in the image as Cat or Dog in the testing or unseen data.

The dataset we will be using in this Image classification report is the Dog Vs Cats dataset available on Kaggle. 
The link to refer or download original dataset is https://www.kaggle.com/c/dogs-vs-cats/data 

The dataset is comprised of 25,000 images of dogs and cats. The images have significant variation in pose.

#### AGENDA 


1. Dataset Acquisition
2. Dataset Pre-processing
3. Implementing a KNN
4. Implementing a Decision Tree classifier
5. Implementing a K-Means classifier
6. Implementing a Random Forest Classifier
7. Implementing a CNN Classifier
8. Results
9. Conclusion

Lets go step by step to classify images.

First, let’s import the required packages as follows:


```python
import numpy as np 
import pandas as pd 

import cv2

import matplotlib.pyplot as plt
import seaborn as sns
%matplotlib inline


import tensorflow as tf
from tensorflow import keras 
from tensorflow.keras import layers
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split

from sklearn.preprocessing import MinMaxScaler

from imutils import paths

import os
from sklearn.neighbors import KNeighborsClassifier

from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.cluster import KMeans

import sys
import os
print(os.listdir("D:\Sem 2\App ML\Assignment 2\Project2_files\Project2_files\data"))
```

    ['test', 'train']
    

Set training and testing path in a variable to be used for further processing.


```python
train_path = os.path.join("D:/Sem 2/App ML/Assignment 2/Project2_files/Project2_files/data/", 'train')
print(train_path)
test_path = os.path.join("D:/Sem 2/App ML/Assignment 2/Project2_files/Project2_files/data/", 'test')
print(test_path)
```

    D:/Sem 2/App ML/Assignment 2/Project2_files/Project2_files/data/train
    D:/Sem 2/App ML/Assignment 2/Project2_files/Project2_files/data/test
    

#### IMAGE PRE-PROCESSING 

Every image has its own story, it contains a lot of information that can be used in many ways. In order to deduce useful information image needs to be pre-processed. 

In data analysis, data pre-processing or data cleansing is a crucial step and most of the ML engineers spend a good amount of time in data pre-processing before building the model.Similarly, Image pre-processing is the term for operations on images at the lowest level of abstraction. These operations do not increase image information content but they decrease it if entropy is an information measure. The aim of pre-processing is an improvement of the image data that suppresses undesired distortions or enhances some image features relevant for further processing and analysis task. 

There are quite a lot different types of Image pre-processing techniques and we will use some of them below.

Initially its not necessary that all the images have similar size so as part of Image pre-processing, we have normalised, resized the image to 96*96 pixel and flattening the image.

Images are in the form of  Multi-Dimensional arrays take more amount of memory while 1-D arrays take less memory, which is the most important reason why we flatten the Image Array before processing/feeding the information to our model.


```python
# Function for pre-processing of images
def createImageFeatures(image, size=(96,96)):
    # resize the image
    image = cv2.resize(image, size)
    # flatten the image
    pixel_list = image.flatten()
    return pixel_list
```

Reading all the images from training directory, pre-processing images and storing original image, pre-processed image and their labels as cat or dog in lists allImages, raw_images and  labels respectively.


```python
# Reading all images
image_paths = list(paths.list_images(train_path))
#print(image_paths)
raw_images = []
labels = []
allImages = [] 

# loop over the input images
for (i, image_path) in enumerate(image_paths):
    image = cv2.imread(image_path)
    allImages.append(image)
    label = image_path.split(os.path.sep)[-1].split(".")[0]
    # extract raw pixel intensity "features
    pixels = createImageFeatures(image)
    raw_images.append(pixels)
    labels.append(label)
```

Displaying Images form dataset


```python
window_name = 'image'

for index, item in zip(range(10), allImages):
    cv2.imshow('ImageWindow', item)   
    cv2.waitKey()
```

Now we have the pre-processed image, next we move on to further step of splitting the images in training and test data frames with the labels as Cat and dog as well.


```python
raw_images = np.array(raw_images)
labels = np.array(labels)
# Split dataset
(train_X, test_X, train_y, test_y) = train_test_split(
    raw_images, labels, test_size=0.25, random_state=0)
```


```python
# print splitted data frames
print("train ",train_X)
print("test ",test_X)
```

    train  [[ 89 123 149 ... 142 151 161]
     [126 120 143 ... 185 168 181]
     [ 77  83  78 ...  55  74  77]
     ...
     [114 120 115 ...  87  99 107]
     [198 208 202 ... 124 130 133]
     [ 59  56  51 ... 105 108 116]]
    test  [[ 55  46  54 ... 134 162 197]
     [ 20  22 194 ...  20  22 194]
     [148 144 143 ...  17  90 100]
     ...
     [ 80 106 118 ...  39  44  43]
     [ 89  81 113 ... 234 235 233]
     [ 30  33  38 ... 101  99  99]]
    


```python
# printing shapes of image data frames
print('Training data shape: ', train_X.shape)
print('Training labels shape: ', train_y.shape)
print('Test data shape: ', test_X.shape)
print('Test labels shape: ', test_y.shape)
```

    Training data shape:  (751, 27648)
    Training labels shape:  (751,)
    Test data shape:  (251, 27648)
    Test labels shape:  (251,)
    


```python
# Normalization - we divide by 255 to put images into a common statistical distribution in terms of size and pixel values
x_train = train_X/255.0
x_test = test_X/255.0
```


```python
# printing normalised data frames
print("train ",x_train)
print("test ",x_test)
```

    train  [[0.34901961 0.48235294 0.58431373 ... 0.55686275 0.59215686 0.63137255]
     [0.49411765 0.47058824 0.56078431 ... 0.7254902  0.65882353 0.70980392]
     [0.30196078 0.3254902  0.30588235 ... 0.21568627 0.29019608 0.30196078]
     ...
     [0.44705882 0.47058824 0.45098039 ... 0.34117647 0.38823529 0.41960784]
     [0.77647059 0.81568627 0.79215686 ... 0.48627451 0.50980392 0.52156863]
     [0.23137255 0.21960784 0.2        ... 0.41176471 0.42352941 0.45490196]]
    test  [[0.21568627 0.18039216 0.21176471 ... 0.5254902  0.63529412 0.77254902]
     [0.07843137 0.08627451 0.76078431 ... 0.07843137 0.08627451 0.76078431]
     [0.58039216 0.56470588 0.56078431 ... 0.06666667 0.35294118 0.39215686]
     ...
     [0.31372549 0.41568627 0.4627451  ... 0.15294118 0.17254902 0.16862745]
     [0.34901961 0.31764706 0.44313725 ... 0.91764706 0.92156863 0.91372549]
     [0.11764706 0.12941176 0.14901961 ... 0.39607843 0.38823529 0.38823529]]
    

Shapes of the data frames


```python
# printing shapes of normalised image data frames
print('Training data shape: ', train_X.shape)
print('Training labels shape: ', train_y.shape)
print('Test data shape: ', test_X.shape)
print('Test labels shape: ', test_y.shape)
```

    Training data shape:  (751, 27648)
    Training labels shape:  (751,)
    Test data shape:  (251, 27648)
    Test labels shape:  (251,)
    

Here the first parameter (751) is the number of images in data frame and other parameter (27648) is multiplication of our resized image size i.e. 96 * 96 by 3 which is the RGB color code.


```python
# printing type of data frames - all the data frames are numpy array
print(type(train_X))
print(type(test_X))
print(type(train_y))
print(type(test_y))
```

    <class 'numpy.ndarray'>
    <class 'numpy.ndarray'>
    <class 'numpy.ndarray'>
    <class 'numpy.ndarray'>
    

Since the images are in appropriate format after normalising and pre-processing, we can now train our data frames in multiple machine learning models and will try to identify which model performs best or fits best for the data sets.

### Test Data 


```python
data = []
label = []
c = 0
d = 0

for file in os.listdir(test_path):
    img=cv2.imread(test_path+"/"+file)
    img=cv2.resize(img,dsize=(96,96))
    img=img.astype('float32')
    if file[:3]=='cat':
        if c==100: continue
        c+=1
        label.append("cat")
    else:
        if d==100: continue
        d+=1
        label.append("dog")
    data.append(img)
data = np.array(data)
```


```python
data_label = []
for i in label:
    if i=="cat": data_label.append(0)
    else: data_label.append(1)
data_label = np.array(data_label)
```


```python
data = data/255.0
reshaped_data = data.reshape(len(data),-1)
```

# Implementing KNN Model

KNN stands for K nearest neighbour and is one the supervised machine learning model, which can be utilised to solve multi-class classification problems. It learns from a labelled training set by taking in the training data X along with it’s labels y and learns to map the input X to it’s desired output y.

Though KNN is not very preferable in terms of image classification, still will see how it performs on our dataset.

It is implemented in sklearn using KNeighborsClassifier class. We begin by importing it:


```python
#importing KNeighborsClassifier class
from sklearn.neighbors import KNeighborsClassifier
# we can choose any number of neighbours 
knn=KNeighborsClassifier(n_neighbors=5)
```


```python
knn.fit(x_train,train_y)
```




    KNeighborsClassifier()




```python
y_pred_knn=knn.predict(x_test)
y_pred_knn
```




    array(['cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog',
           'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog', 'cat', 'dog',
           'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat', 'dog', 'dog',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat',
           'cat', 'dog', 'dog', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat',
           'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'dog', 'dog',
           'dog', 'cat', 'cat', 'dog', 'dog', 'dog', 'dog', 'dog', 'cat',
           'cat', 'cat', 'cat', 'dog', 'dog', 'dog', 'cat', 'cat', 'dog',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat',
           'cat', 'dog', 'cat', 'dog', 'cat', 'cat', 'cat', 'dog', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat',
           'dog', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'dog',
           'cat', 'cat', 'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'dog',
           'cat', 'cat', 'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat',
           'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat',
           'dog', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog',
           'dog', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat',
           'dog', 'dog', 'cat', 'dog', 'cat', 'cat', 'dog', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog',
           'cat', 'cat', 'dog', 'dog', 'cat', 'dog', 'dog', 'dog', 'cat',
           'cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog',
           'cat', 'dog', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat',
           'cat', 'dog', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog',
           'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat'],
          dtype='<U3')




```python
accuracy_score(y_pred_knn,test_y)
print(classification_report(y_pred_knn,test_y))
```

                  precision    recall  f1-score   support
    
             cat       0.74      0.51      0.61       177
             dog       0.33      0.57      0.42        74
    
        accuracy                           0.53       251
       macro avg       0.53      0.54      0.51       251
    weighted avg       0.62      0.53      0.55       251
    
    


```python
confusion_matrix(y_pred_knn,test_y)
```




    array([[91, 86],
           [32, 42]], dtype=int64)



With k vlaue as 5 the accuracy is 53%

Petrforming K-fold Cross fold validation to find out the optimum value of k neighbours. In k-fold cross-validation, the original sample is randomly partitioned into k equal size subsamples.


```python
from sklearn.model_selection import cross_val_score
# choose k between 1 to 31
k_range = range(1, 31)
k_scores = []
# use iteration to caclulator different k in models, then return the average accuracy based on the cross validation
for k in k_range:
    knn = KNeighborsClassifier(n_neighbors=k)
    scores = cross_val_score(knn, x_train,train_y, cv=5, scoring='accuracy')
    k_scores.append(scores.mean())
# plot to see clearly
plt.plot(k_range, k_scores)
plt.xlabel('Value of K for KNN')
plt.ylabel('Cross-Validated Accuracy')
plt.show()
```


    
![png](output_42_0.png)
    


As we can see the best K is around 11, after 13 the accuracy got decreased due to under-fitting.


```python
knn_cv =KNeighborsClassifier(n_neighbors=11)
```


```python
knn_cv.fit(x_train,train_y)
```




    KNeighborsClassifier(n_neighbors=11)




```python
pred_knn=knn_cv.predict(x_test)
```


```python
accuracy_score(pred_knn,test_y)
print(classification_report(pred_knn,test_y))
```

                  precision    recall  f1-score   support
    
             cat       0.80      0.53      0.63       186
             dog       0.31      0.62      0.41        65
    
        accuracy                           0.55       251
       macro avg       0.55      0.57      0.52       251
    weighted avg       0.67      0.55      0.58       251
    
    

Now the accuracy is increased by 2 percent with k value as 11. Final accuracy is 55%

# Implementing Decision Tree Model

Decision tree builds classification or regression models in the form of a tree structure. It breaks down a dataset into smaller and smaller subsets while at the same time an associated decision tree is incrementally developed. The final result is a tree with decision nodes and leaf nodes.

It is implemented in sklearn using the DecisionTreeClassifier class. We begin by importing it:


```python
from sklearn.tree import DecisionTreeClassifier
```


```python
dtc=DecisionTreeClassifier()
```


```python
dtc.fit(x_train,train_y)
```




    DecisionTreeClassifier()




```python
y_pred_dtc=dtc.predict(x_test)
y_pred_dtc
```




    array(['cat', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog',
           'cat', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'cat', 'dog',
           'dog', 'cat', 'dog', 'dog', 'dog', 'cat', 'cat', 'dog', 'dog',
           'dog', 'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat',
           'cat', 'dog', 'cat', 'dog', 'dog', 'cat', 'cat', 'dog', 'cat',
           'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat',
           'dog', 'cat', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat', 'cat',
           'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat',
           'cat', 'dog', 'dog', 'cat', 'dog', 'dog', 'cat', 'dog', 'cat',
           'dog', 'dog', 'dog', 'cat', 'dog', 'dog', 'cat', 'dog', 'dog',
           'dog', 'cat', 'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat',
           'dog', 'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog',
           'cat', 'dog', 'dog', 'cat', 'dog', 'dog', 'dog', 'cat', 'dog',
           'cat', 'dog', 'dog', 'cat', 'cat', 'dog', 'cat', 'dog', 'dog',
           'dog', 'dog', 'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat',
           'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat', 'dog', 'cat',
           'dog', 'dog', 'cat', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat',
           'dog', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat',
           'dog', 'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'dog', 'dog',
           'cat', 'dog', 'cat', 'dog', 'dog', 'dog', 'cat', 'dog', 'dog',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog',
           'dog', 'dog', 'dog', 'dog', 'cat', 'dog', 'dog', 'cat', 'dog',
           'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat',
           'dog', 'dog', 'cat', 'dog', 'cat', 'dog', 'dog', 'dog', 'cat',
           'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'cat',
           'cat', 'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat'],
          dtype='<U3')




```python
accuracy_score(y_pred_dtc,test_y)
print(classification_report(y_pred_dtc,test_y))
```

                  precision    recall  f1-score   support
    
             cat       0.47      0.51      0.49       114
             dog       0.56      0.53      0.54       137
    
        accuracy                           0.52       251
       macro avg       0.52      0.52      0.52       251
    weighted avg       0.52      0.52      0.52       251
    
    


```python
confusion_matrix(y_pred_dtc,test_y)
```




    array([[58, 56],
           [65, 72]], dtype=int64)



We got 52% accuracy with decision tree model now lets perform Cross validation.Cross validation isn't used for buliding/pruning the decision tree. It's used to estimate how good the tree (built on all of the data) lets see now.


```python
cross_val_score(dtc, x_train,train_y, cv=10)
```




    array([0.5       , 0.56      , 0.57333333, 0.46666667, 0.57333333,
           0.54666667, 0.56      , 0.52      , 0.42666667, 0.54666667])



We can see that Decison tree gives maximum of 57% accuracy.

# Implementing K-means Model


```python
clusters = kmeans.fit_predict(x_train)
kmeans.cluster_centers_.shape
```

    C:\Users\sonip\anaconda3\lib\site-packages\sklearn\cluster\_kmeans.py:887: UserWarning: MiniBatchKMeans is known to have a memory leak on Windows with MKL, when there are less chunks than available threads. You can prevent it by setting batch_size >= 2048 or by setting the environment variable OMP_NUM_THREADS=1
      warnings.warn(
    




    (2, 27648)




```python
data_label = []
for i in train_y:
    if i=="cat": data_label.append(0)
    else: data_label.append(1)
data_label = np.array(data_label)
```

This is the standard code for k-means clustering defined in sklearn. kmeans.cluster_centers_ contains 2 centroids with 3072 sizes. These centroids may or may not lie on images from the dataset.


```python
x_data = [i for i in range(27648)]
plt.scatter(x_data,kmeans.cluster_centers_[0], color = 'red',alpha=0.2,s=70)
plt.scatter(x_data,kmeans.cluster_centers_[1] , color = 'blue',alpha=0.2,s=50)
```




    <matplotlib.collections.PathCollection at 0x1af96ecca00>




    
![png](output_64_1.png)
    


In the above image, we can see that some points are intersecting. This shows that K-Means will be confused while classification. The best value is where they both are completely separated. We have used the x-axis of 3072 because that is the size of our image. And plotted image value in the y-axis.


```python
# mapping labels from cluster to original labels
def get_reference_dict(clusters,data_label):
    reference_label = {}
    # For loop to run through each label of cluster label
    for i in range(len(np.unique(clusters))):
        index = np.where(clusters == i,1,0)
        num = np.bincount(data_label[index==1]).argmax()
        reference_label[i] = num
    return reference_label
# Mapping predictions to original labels
def get_labels(clusters,refernce_labels):
    temp_labels = np.random.rand(len(clusters))
    for i in range(len(clusters)):
        temp_labels[i] = reference_labels[clusters[i]]
    return temp_labels
```


```python
reference_labels = get_reference_dict(clusters,data_label)
predicted_labels = get_labels(clusters,reference_labels)
print(accuracy_score(predicted_labels,data_label))
```

    0.5166444740346205
    

ELBOW METHOD


```python
sse = []
list_k = [2,16,64,100,256]
for k in list_k:
    km = KMeans(n_clusters=k)
    clusters = km.fit_predict(X_train)
    sse.append(km.inertia_)
    reference_labels = get_reference_dict(clusters,data_label)
    predicted_labels = get_labels(clusters,reference_labels)
    print(f"Accuracy for k = {k}: ", accuracy_score(predicted_labels,data_label))
# Plot sse against k
plt.figure(figsize=(6, 6))
plt.plot(list_k, sse, '-o')
plt.xlabel(r'Number of clusters *k*')
plt.ylabel('Sum of squared distance');
```

    Accuracy for k = 2:  0.511318242343542
    Accuracy for k = 16:  0.59254327563249
    Accuracy for k = 64:  0.6284953395472703
    Accuracy for k = 100:  0.644474034620506
    Accuracy for k = 256:  0.7443408788282291
    


    
![png](output_69_1.png)
    


We are we getting better accuracy at 256 instead of 2 when we know that our data contains only 2 different classes, there could be many reasons for this observation. Maybe some cats look more like dogs or maybe some cats are different from other cats. You can try an experiment to apply k-means to a dataset where you only have one breed of dog and one breed of cat. K-Means will perform pretty awesome in that case. We are getting these many clusters because there could beside photos of cats, that will surely look different from the front side. All of this is because our model doesn’t know anything about cats and dogs until we have given it the data to form clusters. It is the same as you do not know about cars and someone wants you to form clusters of cars with the same features (like the same engine power, etc).

We can further improve performance by something called Transfer learning (TL) is a research problem in machine learning (ML) that focuses on storing knowledge gained while solving one problem and applying it to a different but related problem.

# storing in data frame


```python
train_df = pd.DataFrame({'image_name':os.listdir(train_path)})
train_df['label'] =train_df['image_name'].apply(lambda x: x.split('.')[0])
train_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>image_name</th>
      <th>label</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>cat.0.jpg</td>
      <td>cat</td>
    </tr>
    <tr>
      <th>1</th>
      <td>cat.1.jpg</td>
      <td>cat</td>
    </tr>
    <tr>
      <th>2</th>
      <td>cat.10.jpg</td>
      <td>cat</td>
    </tr>
    <tr>
      <th>3</th>
      <td>cat.100.jpg</td>
      <td>cat</td>
    </tr>
    <tr>
      <th>4</th>
      <td>cat.101.jpg</td>
      <td>cat</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>997</th>
      <td>dog.95.jpg</td>
      <td>dog</td>
    </tr>
    <tr>
      <th>998</th>
      <td>dog.96.jpg</td>
      <td>dog</td>
    </tr>
    <tr>
      <th>999</th>
      <td>dog.97.jpg</td>
      <td>dog</td>
    </tr>
    <tr>
      <th>1000</th>
      <td>dog.98.jpg</td>
      <td>dog</td>
    </tr>
    <tr>
      <th>1001</th>
      <td>dog.99.jpg</td>
      <td>dog</td>
    </tr>
  </tbody>
</table>
<p>1002 rows × 2 columns</p>
</div>




```python
train_df["label"].value_counts()
```




    cat    501
    dog    501
    Name: label, dtype: int64



# Implementing Random forest

Random forests is a supervised learning algorithm. It can be used both for classification and regression. It is also the most flexible and easy to use algorithm. A forest is comprised of trees. It is said that the more trees it has, the more robust a forest is.

Let’s build a Random Forest Classifier, For this, we must first import it from sklearn:


```python
from sklearn.ensemble import RandomForestClassifier
```

Create an instance of the RandomForestClassifier class:


```python
model=RandomForestClassifier(n_estimators=100)
```

Finally, let us proceed to train the model:


```python
model.fit(X_train, train_y)
```




    RandomForestClassifier()




```python
y_pred=model.predict(test_X)
y_pred
```




    array(['cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog', 'cat', 'cat',
           'dog', 'cat', 'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat',
           'cat', 'dog', 'cat', 'dog', 'cat', 'dog', 'cat', 'cat', 'dog',
           'dog', 'cat', 'dog', 'cat', 'cat', 'dog', 'cat', 'dog', 'dog',
           'cat', 'dog', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'cat',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'dog', 'cat',
           'dog', 'dog', 'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'cat',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'dog', 'dog',
           'cat', 'dog', 'cat', 'dog', 'dog', 'dog', 'dog', 'cat', 'dog',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'cat',
           'cat', 'dog', 'cat', 'cat', 'dog', 'dog', 'dog', 'cat', 'dog',
           'dog', 'cat', 'cat', 'dog', 'cat', 'dog', 'cat', 'cat', 'cat',
           'dog', 'dog', 'cat', 'cat', 'dog', 'dog', 'cat', 'cat', 'dog',
           'dog', 'cat', 'cat', 'dog', 'cat', 'dog', 'cat', 'cat', 'cat',
           'cat', 'cat', 'dog', 'dog', 'dog', 'cat', 'dog', 'dog', 'dog',
           'cat', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat', 'dog', 'cat',
           'dog', 'cat', 'cat', 'dog', 'dog', 'cat', 'dog', 'cat', 'cat',
           'dog', 'dog', 'cat', 'dog', 'cat', 'dog', 'cat', 'dog', 'dog',
           'cat', 'cat', 'cat', 'cat', 'dog', 'cat', 'cat', 'dog', 'cat',
           'cat', 'dog', 'cat', 'cat', 'dog', 'dog', 'dog', 'dog', 'dog',
           'cat', 'dog', 'cat', 'dog', 'dog', 'cat', 'cat', 'cat', 'cat',
           'cat', 'cat', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'dog',
           'dog', 'dog', 'dog', 'cat', 'dog', 'cat', 'dog', 'cat', 'cat',
           'dog', 'cat', 'cat', 'cat', 'cat', 'dog', 'dog', 'dog', 'dog',
           'dog', 'cat', 'dog', 'cat', 'cat', 'dog', 'dog', 'dog', 'cat',
           'dog', 'dog', 'cat', 'cat', 'cat', 'dog', 'cat', 'dog', 'cat',
           'cat', 'dog', 'dog', 'dog', 'cat', 'dog', 'cat', 'dog'],
          dtype='<U3')




```python
acc = model.score(test_X, test_y)
print("Raw pixel accuracy: {:.2f}%".format(acc * 100))
```

    Raw pixel accuracy: 64.54%
    


```python
Random  forest gives accuracy of 64.54%.
```


```python
accuracy_score(y_pred,test_y)
print(classification_report(y_pred,test_y))
```

                  precision    recall  f1-score   support
    
             cat       0.70      0.62      0.66       138
             dog       0.59      0.67      0.63       113
    
        accuracy                           0.65       251
       macro avg       0.65      0.65      0.64       251
    weighted avg       0.65      0.65      0.65       251
    
    


```python
confusion_matrix(y_pred,test_y)
```




    array([[  0,   0],
           [123, 128]], dtype=int64)



# Implementing CNN Model

CNN is a powerful algorithm for image processing. These algorithms are currently the best algorithms we have for the automated processing of images.

Convolutional Neural Networks specialized for applications in image & video recognition. CNN is mainly used in image analysis tasks like Image recognition, Object detection & Segmentation.

There are three types of layers in Convolutional Neural Networks:

1) Convolutional Layer: In a typical neural network each input neuron is connected to the next hidden layer. In CNN, only a small region of the input layer neurons connect to the neuron hidden layer.

2) Pooling Layer: The pooling layer is used to reduce the dimensionality of the feature map. There will be multiple activation & pooling layers inside the hidden layer of the CNN.

3) Fully-Connected layer: Fully Connected Layers form the last few layers in the network. The input to the fully connected layer is the output from the final Pooling or Convolutional Layer, which is flattened and then fed into the fully connected layer.


```python
#splitting data for CNN
from sklearn.model_selection import train_test_split
x_train, x_val = train_test_split(train_df, test_size=0.2, random_state=2)
```


```python
x_train.head(), x_val.head()
```




    (      image_name label
     175  cat.256.jpg   cat
     510  dog.106.jpg   dog
     453   cat.56.jpg   cat
     374  cat.435.jpg   cat
     200  cat.279.jpg   cat,
           image_name label
     37   cat.131.jpg   cat
     398  cat.457.jpg   cat
     384  cat.444.jpg   cat
     825  dog.390.jpg   dog
     812  dog.379.jpg   dog)




```python
#resetting indexes to start from 0
x_train = x_train.reset_index(drop=True)
x_val = x_val.reset_index(drop=True)
```


```python
x_train.head(), x_val.head()
```




    (    image_name label
     0  cat.256.jpg   cat
     1  dog.106.jpg   dog
     2   cat.56.jpg   cat
     3  cat.435.jpg   cat
     4  cat.279.jpg   cat,
         image_name label
     0  cat.131.jpg   cat
     1  cat.457.jpg   cat
     2  cat.444.jpg   cat
     3  dog.390.jpg   dog
     4  dog.379.jpg   dog)



Since there is not much of data and CNN performs best with more data we use image augmentation. The image augmentation technique is a great way to expand the size of your dataset.

Image augmentation is a technique of applying different transformations to original images which results in multiple transformed copies of the same image. Each copy, however, is different from the other in certain aspects depending on the augmentation techniques you apply like shifting, rotating, flipping, etc.

Applying these small amounts of variations on the original image does not change its target class but only provides a new perspective of capturing the object in real life. And so, we use it is quite often for building deep learning models.

It lets you augment your images in real-time while your model is still training! You can apply any random transformations on each training image as it is passed to the model. This will not only make your model robust but will also save up on the overhead memory!

Image data generators for training and validation data being prepared below with various processing being applied on images.


```python
from tensorflow.keras.preprocessing.image import ImageDataGenerator
train_datagen = ImageDataGenerator(
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest',
    rescale=1./255)


valid_datagen = ImageDataGenerator(
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True,
    fill_mode='nearest',
    rescale=1./255)
```


```python
from tensorflow.keras.preprocessing import image
fnames = [os.path.join(train_path, filename) for filename in os.listdir(train_path)]
img_path = fnames[3]

img = image.load_img(img_path, target_size=(128, 128))
x = image.img_to_array(img)
x = x.reshape((1,) + x.shape)

i = 0
for batch in train_datagen.flow(x, batch_size=1):
 plt.figure(i)
 imgplot = plt.imshow(image.array_to_img(batch[0]))
 i += 1
 if i % 4 == 0:
        break
plt.show()
```


    
![png](output_94_0.png)
    



    
![png](output_94_1.png)
    



    
![png](output_94_2.png)
    



    
![png](output_94_3.png)
    


The flow_from_dataframe() method takes the Pandas DataFrame and the path to a directory and generates batches of augmented/normalized data.


```python
train_generator = train_datagen.flow_from_dataframe(
    x_train,
    train_path, 
    x_col='image_name',
    y_col='label',
    target_size=(128,128),
    class_mode='categorical',
    batch_size=15
 )

valid_generator = valid_datagen.flow_from_dataframe( 
    x_val,
    train_path, 
    x_col='image_name',
    y_col='label',
    target_size=(128,128),
    class_mode='categorical',
    batch_size=15
 )
```

    Found 801 validated image filenames belonging to 2 classes.
    Found 201 validated image filenames belonging to 2 classes.
    


```python
for data_batch, labels_batch in train_generator:
    print('data batch shape:', data_batch.shape)
    print('labels batch shape:', labels_batch.shape)
    break
```

    data batch shape: (15, 128, 128, 3)
    labels batch shape: (15, 2)
    

where 15 is the number of samples in each batch, 96 * 96 refers to the height and width of the image and 3 refers to the RGB.


```python
for data_batch, labels_batch in valid_generator:
    print('data batch shape:', data_batch.shape)
    print('labels batch shape:', labels_batch.shape)
    break
```

    data batch shape: (15, 128, 128, 3)
    labels batch shape: (15, 2)
    

Let’s define the Convolutional Neural Network (CNN)


```python
model = keras.models.Sequential([
                         keras.layers.Conv2D(filters=64, kernel_size=3, strides=(1,1), padding='valid',activation= 'relu', input_shape=(128,128,3)),
                         keras.layers.MaxPooling2D(pool_size=(2,2)),
                         keras.layers.Conv2D(filters=128, kernel_size=3, strides=(2,2), padding='same', activation='relu'),
                         keras.layers.MaxPooling2D(pool_size=(2,2)),
                         keras.layers.Conv2D(filters=64, kernel_size=3, strides=(2,2), padding='same', activation='relu'),
                         keras.layers.MaxPooling2D(pool_size=(2,2)),
                         keras.layers.Flatten(),
                         keras.layers.Dense(units=128, activation='relu'),
                         keras.layers.Dropout(0.25),
                         keras.layers.Dense(units=256, activation='relu'),
                         keras.layers.Dropout(0.5),
                         keras.layers.Dense(units=256, activation='relu'),
                         keras.layers.Dropout(0.25),                        
                         keras.layers.Dense(units=128, activation='relu'),
                         keras.layers.Dropout(0.10),                         
                         keras.layers.Dense(units=2, activation='softmax')
])
```

Let's display the architecture of our model so far:


```python
model.summary()
```

    Model: "sequential_4"
    _________________________________________________________________
     Layer (type)                Output Shape              Param #   
    =================================================================
     conv2d_12 (Conv2D)          (None, 126, 126, 64)      1792      
                                                                     
     max_pooling2d_12 (MaxPoolin  (None, 63, 63, 64)       0         
     g2D)                                                            
                                                                     
     conv2d_13 (Conv2D)          (None, 32, 32, 128)       73856     
                                                                     
     max_pooling2d_13 (MaxPoolin  (None, 16, 16, 128)      0         
     g2D)                                                            
                                                                     
     conv2d_14 (Conv2D)          (None, 8, 8, 64)          73792     
                                                                     
     max_pooling2d_14 (MaxPoolin  (None, 4, 4, 64)         0         
     g2D)                                                            
                                                                     
     flatten_4 (Flatten)         (None, 1024)              0         
                                                                     
     dense_20 (Dense)            (None, 128)               131200    
                                                                     
     dropout_16 (Dropout)        (None, 128)               0         
                                                                     
     dense_21 (Dense)            (None, 256)               33024     
                                                                     
     dropout_17 (Dropout)        (None, 256)               0         
                                                                     
     dense_22 (Dense)            (None, 256)               65792     
                                                                     
     dropout_18 (Dropout)        (None, 256)               0         
                                                                     
     dense_23 (Dense)            (None, 128)               32896     
                                                                     
     dropout_19 (Dropout)        (None, 128)               0         
                                                                     
     dense_24 (Dense)            (None, 2)                 258       
                                                                     
    =================================================================
    Total params: 412,610
    Trainable params: 412,610
    Non-trainable params: 0
    _________________________________________________________________
    

Compiling our CNN model


```python
model.compile(loss='categorical_crossentropy',
 optimizer="adam",
 metrics=['accuracy'])
```

Training model


```python
history = model.fit(train_generator, epochs=100, verbose=1, validation_data=valid_generator)
```

    Epoch 1/100
    54/54 [==============================] - 21s 362ms/step - loss: 0.6968 - accuracy: 0.4994 - val_loss: 0.6928 - val_accuracy: 0.5075
    Epoch 2/100
    54/54 [==============================] - 18s 328ms/step - loss: 0.6943 - accuracy: 0.4956 - val_loss: 0.6950 - val_accuracy: 0.4925
    Epoch 3/100
    54/54 [==============================] - 18s 337ms/step - loss: 0.6943 - accuracy: 0.4919 - val_loss: 0.6931 - val_accuracy: 0.4925
    Epoch 4/100
    54/54 [==============================] - 17s 322ms/step - loss: 0.6936 - accuracy: 0.5119 - val_loss: 0.6941 - val_accuracy: 0.4925
    Epoch 5/100
    54/54 [==============================] - 18s 326ms/step - loss: 0.6975 - accuracy: 0.4981 - val_loss: 0.6934 - val_accuracy: 0.4925
    Epoch 6/100
    54/54 [==============================] - 18s 335ms/step - loss: 0.6936 - accuracy: 0.4844 - val_loss: 0.6932 - val_accuracy: 0.4677
    Epoch 7/100
    54/54 [==============================] - 18s 336ms/step - loss: 0.6942 - accuracy: 0.5044 - val_loss: 0.6930 - val_accuracy: 0.5075
    Epoch 8/100
    54/54 [==============================] - 18s 325ms/step - loss: 0.6950 - accuracy: 0.4894 - val_loss: 0.6926 - val_accuracy: 0.5075
    Epoch 9/100
    54/54 [==============================] - 18s 338ms/step - loss: 0.6938 - accuracy: 0.4844 - val_loss: 0.6924 - val_accuracy: 0.5075
    Epoch 10/100
    54/54 [==============================] - 18s 322ms/step - loss: 0.6940 - accuracy: 0.4956 - val_loss: 0.6934 - val_accuracy: 0.4925
    Epoch 11/100
    54/54 [==============================] - 18s 326ms/step - loss: 0.6947 - accuracy: 0.4906 - val_loss: 0.6938 - val_accuracy: 0.4925
    Epoch 12/100
    54/54 [==============================] - 18s 328ms/step - loss: 0.6943 - accuracy: 0.4732 - val_loss: 0.6929 - val_accuracy: 0.5075
    Epoch 13/100
    54/54 [==============================] - 18s 336ms/step - loss: 0.6932 - accuracy: 0.5056 - val_loss: 0.6927 - val_accuracy: 0.4925
    Epoch 14/100
    54/54 [==============================] - 17s 316ms/step - loss: 0.6913 - accuracy: 0.5081 - val_loss: 0.6914 - val_accuracy: 0.5224
    Epoch 15/100
    54/54 [==============================] - 18s 327ms/step - loss: 0.6915 - accuracy: 0.5306 - val_loss: 0.6940 - val_accuracy: 0.5075
    Epoch 16/100
    54/54 [==============================] - 18s 333ms/step - loss: 0.6938 - accuracy: 0.4881 - val_loss: 0.6907 - val_accuracy: 0.5473
    Epoch 17/100
    54/54 [==============================] - 18s 330ms/step - loss: 0.6819 - accuracy: 0.5543 - val_loss: 0.6785 - val_accuracy: 0.5821
    Epoch 18/100
    54/54 [==============================] - 18s 325ms/step - loss: 0.6934 - accuracy: 0.5268 - val_loss: 0.6787 - val_accuracy: 0.4925
    Epoch 19/100
    54/54 [==============================] - 18s 330ms/step - loss: 0.6776 - accuracy: 0.5743 - val_loss: 0.6840 - val_accuracy: 0.5174
    Epoch 20/100
    54/54 [==============================] - 18s 336ms/step - loss: 0.6763 - accuracy: 0.5743 - val_loss: 0.6945 - val_accuracy: 0.4975
    Epoch 21/100
    54/54 [==============================] - 18s 335ms/step - loss: 0.6975 - accuracy: 0.5169 - val_loss: 0.6951 - val_accuracy: 0.4925
    Epoch 22/100
    54/54 [==============================] - 19s 341ms/step - loss: 0.6956 - accuracy: 0.4844 - val_loss: 0.6929 - val_accuracy: 0.4975
    Epoch 23/100
    54/54 [==============================] - 19s 343ms/step - loss: 0.6935 - accuracy: 0.4944 - val_loss: 0.6930 - val_accuracy: 0.4975
    Epoch 24/100
    54/54 [==============================] - 12s 215ms/step - loss: 0.6937 - accuracy: 0.5094 - val_loss: 0.6929 - val_accuracy: 0.4975
    Epoch 25/100
    54/54 [==============================] - 10s 193ms/step - loss: 0.6932 - accuracy: 0.4856 - val_loss: 0.6927 - val_accuracy: 0.5224
    Epoch 26/100
    54/54 [==============================] - 10s 189ms/step - loss: 0.6949 - accuracy: 0.4994 - val_loss: 0.6936 - val_accuracy: 0.4975
    Epoch 27/100
    54/54 [==============================] - 10s 189ms/step - loss: 0.6948 - accuracy: 0.5144 - val_loss: 0.6934 - val_accuracy: 0.4925
    Epoch 28/100
    54/54 [==============================] - 11s 205ms/step - loss: 0.6939 - accuracy: 0.4869 - val_loss: 0.6916 - val_accuracy: 0.4925
    Epoch 29/100
    54/54 [==============================] - 12s 214ms/step - loss: 0.6929 - accuracy: 0.4944 - val_loss: 0.6875 - val_accuracy: 0.4975
    Epoch 30/100
    54/54 [==============================] - 10s 190ms/step - loss: 0.6838 - accuracy: 0.5643 - val_loss: 0.6823 - val_accuracy: 0.5323
    Epoch 31/100
    54/54 [==============================] - 10s 191ms/step - loss: 0.6949 - accuracy: 0.4956 - val_loss: 0.6932 - val_accuracy: 0.5075
    Epoch 32/100
    54/54 [==============================] - 12s 224ms/step - loss: 0.6954 - accuracy: 0.4969 - val_loss: 0.6929 - val_accuracy: 0.4975
    Epoch 33/100
    54/54 [==============================] - 11s 199ms/step - loss: 0.6938 - accuracy: 0.5044 - val_loss: 0.6930 - val_accuracy: 0.4975
    Epoch 34/100
    54/54 [==============================] - 10s 184ms/step - loss: 0.6932 - accuracy: 0.5019 - val_loss: 0.6929 - val_accuracy: 0.5323
    Epoch 35/100
    54/54 [==============================] - 11s 199ms/step - loss: 0.6934 - accuracy: 0.4981 - val_loss: 0.6931 - val_accuracy: 0.5025
    Epoch 36/100
    54/54 [==============================] - 12s 217ms/step - loss: 0.6934 - accuracy: 0.4769 - val_loss: 0.6933 - val_accuracy: 0.4925
    Epoch 37/100
    54/54 [==============================] - 11s 202ms/step - loss: 0.6940 - accuracy: 0.4881 - val_loss: 0.6925 - val_accuracy: 0.5075
    Epoch 38/100
    54/54 [==============================] - 12s 214ms/step - loss: 0.6940 - accuracy: 0.4856 - val_loss: 0.6931 - val_accuracy: 0.5075
    Epoch 39/100
    54/54 [==============================] - 10s 186ms/step - loss: 0.6933 - accuracy: 0.4956 - val_loss: 0.6926 - val_accuracy: 0.5025
    Epoch 40/100
    54/54 [==============================] - 9s 173ms/step - loss: 0.6929 - accuracy: 0.4981 - val_loss: 0.6916 - val_accuracy: 0.5572
    Epoch 41/100
    54/54 [==============================] - 10s 194ms/step - loss: 0.6907 - accuracy: 0.5281 - val_loss: 0.6892 - val_accuracy: 0.5473
    Epoch 42/100
    54/54 [==============================] - 10s 182ms/step - loss: 0.6871 - accuracy: 0.5431 - val_loss: 0.6857 - val_accuracy: 0.5622
    Epoch 43/100
    54/54 [==============================] - 11s 201ms/step - loss: 0.6887 - accuracy: 0.5568 - val_loss: 0.6828 - val_accuracy: 0.5572
    Epoch 44/100
    54/54 [==============================] - 12s 219ms/step - loss: 0.6878 - accuracy: 0.5506 - val_loss: 0.6892 - val_accuracy: 0.5274
    Epoch 45/100
    54/54 [==============================] - 11s 201ms/step - loss: 0.6773 - accuracy: 0.5918 - val_loss: 0.7109 - val_accuracy: 0.5025
    Epoch 46/100
    54/54 [==============================] - 11s 196ms/step - loss: 0.6867 - accuracy: 0.5718 - val_loss: 0.6867 - val_accuracy: 0.6269
    Epoch 47/100
    54/54 [==============================] - 11s 198ms/step - loss: 0.6846 - accuracy: 0.5893 - val_loss: 0.6838 - val_accuracy: 0.5473
    Epoch 48/100
    54/54 [==============================] - 10s 179ms/step - loss: 0.6862 - accuracy: 0.5581 - val_loss: 0.6706 - val_accuracy: 0.5721
    Epoch 49/100
    54/54 [==============================] - 13s 242ms/step - loss: 0.6717 - accuracy: 0.5918 - val_loss: 0.6858 - val_accuracy: 0.5522
    Epoch 50/100
    54/54 [==============================] - 14s 253ms/step - loss: 0.6888 - accuracy: 0.5368 - val_loss: 0.6759 - val_accuracy: 0.5672
    Epoch 51/100
    54/54 [==============================] - 15s 276ms/step - loss: 0.6807 - accuracy: 0.5680 - val_loss: 0.6809 - val_accuracy: 0.5672
    Epoch 52/100
    54/54 [==============================] - 13s 247ms/step - loss: 0.6821 - accuracy: 0.5830 - val_loss: 0.6723 - val_accuracy: 0.6070
    Epoch 53/100
    54/54 [==============================] - 14s 264ms/step - loss: 0.6812 - accuracy: 0.5718 - val_loss: 0.6732 - val_accuracy: 0.5771
    Epoch 54/100
    54/54 [==============================] - 13s 249ms/step - loss: 0.6755 - accuracy: 0.6280 - val_loss: 0.6875 - val_accuracy: 0.5224
    Epoch 55/100
    54/54 [==============================] - 14s 250ms/step - loss: 0.6615 - accuracy: 0.5843 - val_loss: 0.6511 - val_accuracy: 0.6219
    Epoch 56/100
    54/54 [==============================] - 13s 239ms/step - loss: 0.6599 - accuracy: 0.6080 - val_loss: 0.6719 - val_accuracy: 0.6318
    Epoch 57/100
    54/54 [==============================] - 14s 251ms/step - loss: 0.6486 - accuracy: 0.6292 - val_loss: 0.6558 - val_accuracy: 0.6169
    Epoch 58/100
    54/54 [==============================] - 13s 249ms/step - loss: 0.6610 - accuracy: 0.5980 - val_loss: 0.6857 - val_accuracy: 0.5473
    Epoch 59/100
    54/54 [==============================] - 14s 252ms/step - loss: 0.6680 - accuracy: 0.6080 - val_loss: 0.6563 - val_accuracy: 0.6716
    Epoch 60/100
    54/54 [==============================] - 14s 262ms/step - loss: 0.6436 - accuracy: 0.6629 - val_loss: 0.6446 - val_accuracy: 0.6716
    Epoch 61/100
    54/54 [==============================] - 14s 255ms/step - loss: 0.6353 - accuracy: 0.6554 - val_loss: 0.6689 - val_accuracy: 0.6219
    Epoch 62/100
    54/54 [==============================] - 13s 239ms/step - loss: 0.6344 - accuracy: 0.6704 - val_loss: 0.7046 - val_accuracy: 0.5821
    Epoch 63/100
    54/54 [==============================] - 13s 239ms/step - loss: 0.6324 - accuracy: 0.6554 - val_loss: 0.6635 - val_accuracy: 0.6269
    Epoch 64/100
    54/54 [==============================] - 13s 234ms/step - loss: 0.6500 - accuracy: 0.6055 - val_loss: 0.6510 - val_accuracy: 0.6119
    Epoch 65/100
    54/54 [==============================] - 13s 246ms/step - loss: 0.6276 - accuracy: 0.6654 - val_loss: 0.6875 - val_accuracy: 0.6269
    Epoch 66/100
    54/54 [==============================] - 14s 264ms/step - loss: 0.6375 - accuracy: 0.6554 - val_loss: 0.6714 - val_accuracy: 0.6020
    Epoch 67/100
    54/54 [==============================] - 13s 233ms/step - loss: 0.6417 - accuracy: 0.6454 - val_loss: 0.6303 - val_accuracy: 0.6716
    Epoch 68/100
    54/54 [==============================] - 12s 230ms/step - loss: 0.6248 - accuracy: 0.6429 - val_loss: 0.6346 - val_accuracy: 0.6617
    Epoch 69/100
    54/54 [==============================] - 13s 234ms/step - loss: 0.6238 - accuracy: 0.6579 - val_loss: 0.6502 - val_accuracy: 0.6517
    Epoch 70/100
    54/54 [==============================] - 12s 231ms/step - loss: 0.6021 - accuracy: 0.6717 - val_loss: 0.6515 - val_accuracy: 0.6567
    Epoch 71/100
    54/54 [==============================] - 13s 247ms/step - loss: 0.6226 - accuracy: 0.6654 - val_loss: 0.6548 - val_accuracy: 0.6070
    Epoch 72/100
    54/54 [==============================] - 12s 230ms/step - loss: 0.5966 - accuracy: 0.6679 - val_loss: 0.6238 - val_accuracy: 0.6766
    Epoch 73/100
    54/54 [==============================] - 13s 231ms/step - loss: 0.6116 - accuracy: 0.6592 - val_loss: 0.6381 - val_accuracy: 0.6468
    Epoch 74/100
    54/54 [==============================] - 13s 232ms/step - loss: 0.6027 - accuracy: 0.6804 - val_loss: 0.6034 - val_accuracy: 0.6617
    Epoch 75/100
    54/54 [==============================] - 13s 237ms/step - loss: 0.6002 - accuracy: 0.6854 - val_loss: 0.6071 - val_accuracy: 0.6915
    Epoch 76/100
    54/54 [==============================] - 13s 234ms/step - loss: 0.6017 - accuracy: 0.6679 - val_loss: 0.6557 - val_accuracy: 0.6119
    Epoch 77/100
    54/54 [==============================] - 12s 231ms/step - loss: 0.5665 - accuracy: 0.6916 - val_loss: 0.6297 - val_accuracy: 0.6766
    Epoch 78/100
    54/54 [==============================] - 13s 241ms/step - loss: 0.5977 - accuracy: 0.6941 - val_loss: 0.6413 - val_accuracy: 0.6318
    Epoch 79/100
    54/54 [==============================] - 13s 248ms/step - loss: 0.5728 - accuracy: 0.6954 - val_loss: 0.6263 - val_accuracy: 0.6169
    Epoch 80/100
    54/54 [==============================] - 12s 231ms/step - loss: 0.5757 - accuracy: 0.6929 - val_loss: 0.6165 - val_accuracy: 0.6816
    Epoch 81/100
    54/54 [==============================] - 13s 234ms/step - loss: 0.5835 - accuracy: 0.7066 - val_loss: 0.5928 - val_accuracy: 0.6617
    Epoch 82/100
    54/54 [==============================] - 12s 231ms/step - loss: 0.5629 - accuracy: 0.7154 - val_loss: 0.5598 - val_accuracy: 0.6816
    Epoch 83/100
    54/54 [==============================] - 13s 231ms/step - loss: 0.5878 - accuracy: 0.6829 - val_loss: 0.6242 - val_accuracy: 0.6667
    Epoch 84/100
    54/54 [==============================] - 13s 231ms/step - loss: 0.6048 - accuracy: 0.6816 - val_loss: 0.6098 - val_accuracy: 0.6816
    Epoch 85/100
    54/54 [==============================] - 13s 238ms/step - loss: 0.5907 - accuracy: 0.6754 - val_loss: 0.5978 - val_accuracy: 0.7264
    Epoch 86/100
    54/54 [==============================] - 13s 236ms/step - loss: 0.5641 - accuracy: 0.7341 - val_loss: 0.5976 - val_accuracy: 0.7015
    Epoch 87/100
    54/54 [==============================] - 13s 235ms/step - loss: 0.5780 - accuracy: 0.7004 - val_loss: 0.5829 - val_accuracy: 0.7015
    Epoch 88/100
    54/54 [==============================] - 13s 238ms/step - loss: 0.5571 - accuracy: 0.7228 - val_loss: 0.6175 - val_accuracy: 0.6567
    Epoch 89/100
    54/54 [==============================] - 13s 238ms/step - loss: 0.5472 - accuracy: 0.7353 - val_loss: 0.6050 - val_accuracy: 0.6866
    Epoch 90/100
    54/54 [==============================] - 13s 241ms/step - loss: 0.5302 - accuracy: 0.7366 - val_loss: 0.6007 - val_accuracy: 0.6915
    Epoch 91/100
    54/54 [==============================] - 13s 243ms/step - loss: 0.5517 - accuracy: 0.7266 - val_loss: 0.6220 - val_accuracy: 0.6617
    Epoch 92/100
    54/54 [==============================] - 13s 238ms/step - loss: 0.5569 - accuracy: 0.7241 - val_loss: 0.5947 - val_accuracy: 0.7015
    Epoch 93/100
    54/54 [==============================] - 13s 243ms/step - loss: 0.5548 - accuracy: 0.7054 - val_loss: 0.5661 - val_accuracy: 0.7313
    Epoch 94/100
    54/54 [==============================] - 12s 231ms/step - loss: 0.5612 - accuracy: 0.7004 - val_loss: 0.5529 - val_accuracy: 0.7015
    Epoch 95/100
    54/54 [==============================] - 13s 240ms/step - loss: 0.5256 - accuracy: 0.7441 - val_loss: 0.7030 - val_accuracy: 0.6368
    Epoch 96/100
    54/54 [==============================] - 13s 235ms/step - loss: 0.5512 - accuracy: 0.7154 - val_loss: 0.6028 - val_accuracy: 0.6816
    Epoch 97/100
    54/54 [==============================] - 13s 242ms/step - loss: 0.5757 - accuracy: 0.7179 - val_loss: 0.6047 - val_accuracy: 0.6965
    Epoch 98/100
    54/54 [==============================] - 13s 234ms/step - loss: 0.5424 - accuracy: 0.7141 - val_loss: 0.5785 - val_accuracy: 0.6816
    Epoch 99/100
    54/54 [==============================] - 13s 233ms/step - loss: 0.5618 - accuracy: 0.7216 - val_loss: 0.5935 - val_accuracy: 0.6866
    Epoch 100/100
    54/54 [==============================] - 13s 232ms/step - loss: 0.5306 - accuracy: 0.7378 - val_loss: 0.5953 - val_accuracy: 0.6667
    

Evaluating Model


```python
score, acc = model.evaluate(valid_generator,batch_size=64)                       
print('Test score:', score)
print('Test accuracy:', acc)
```

    14/14 [==============================] - 1s 87ms/step - loss: 0.6216 - accuracy: 0.7313
    Test score: 0.6215668320655823
    Test accuracy: 0.7313432693481445
    


```python
cnn_prediction = model.predict(valid_generator)
cnn_prediction
```




    array([[0.4037461 , 0.59625393],
           [0.6933708 , 0.3066292 ],
           [0.48667303, 0.51332694],
           [0.6733923 , 0.32660767],
           [0.34374815, 0.6562519 ],
           [0.8600441 , 0.13995588],
           [0.48076922, 0.51923084],
           [0.5654804 , 0.43451965],
           [0.72735876, 0.27264124],
           [0.78940654, 0.21059342],
           [0.17724954, 0.82275045],
           [0.4333403 , 0.5666597 ],
           [0.5446523 , 0.45534772],
           [0.42826107, 0.57173896],
           [0.43202177, 0.56797826],
           [0.4676388 , 0.53236127],
           [0.48811457, 0.51188546],
           [0.2496804 , 0.75031966],
           [0.4127637 , 0.5872363 ],
           [0.5403793 , 0.45962074],
           [0.48459768, 0.5154023 ],
           [0.64064467, 0.3593553 ],
           [0.62788993, 0.37211013],
           [0.81571764, 0.18428232],
           [0.60647607, 0.39352402],
           [0.53315663, 0.46684337],
           [0.6656966 , 0.33430344],
           [0.63958925, 0.36041078],
           [0.5244497 , 0.47555026],
           [0.02699705, 0.973003  ],
           [0.72725105, 0.27274898],
           [0.2566444 , 0.7433556 ],
           [0.756847  , 0.24315298],
           [0.5235299 , 0.47647008],
           [0.6907539 , 0.30924615],
           [0.619887  , 0.38011304],
           [0.5103172 , 0.4896828 ],
           [0.42531866, 0.5746814 ],
           [0.327088  , 0.672912  ],
           [0.5997999 , 0.4002001 ],
           [0.69767463, 0.30232537],
           [0.511653  , 0.488347  ],
           [0.3277313 , 0.6722687 ],
           [0.8305789 , 0.16942108],
           [0.5872708 , 0.4127292 ],
           [0.47956017, 0.5204398 ],
           [0.46905458, 0.5309455 ],
           [0.43909317, 0.5609068 ],
           [0.552791  , 0.44720897],
           [0.8650504 , 0.1349496 ],
           [0.434355  , 0.565645  ],
           [0.47243088, 0.5275691 ],
           [0.8551062 , 0.14489381],
           [0.29397732, 0.7060227 ],
           [0.60094035, 0.39905965],
           [0.6188245 , 0.38117552],
           [0.45738158, 0.5426184 ],
           [0.4033596 , 0.5966404 ],
           [0.8449794 , 0.15502067],
           [0.7861877 , 0.21381226],
           [0.9780001 , 0.02199988],
           [0.48123842, 0.5187616 ],
           [0.86102074, 0.13897933],
           [0.49128258, 0.5087174 ],
           [0.7211277 , 0.27887228],
           [0.3890825 , 0.61091745],
           [0.8267033 , 0.17329665],
           [0.80938226, 0.19061773],
           [0.7446877 , 0.25531232],
           [0.8001965 , 0.19980347],
           [0.50230974, 0.49769026],
           [0.7839533 , 0.21604666],
           [0.6369501 , 0.36304998],
           [0.47432563, 0.52567434],
           [0.59231544, 0.40768453],
           [0.41467842, 0.5853216 ],
           [0.8090025 , 0.1909975 ],
           [0.6201575 , 0.37984252],
           [0.50576705, 0.49423292],
           [0.73557127, 0.2644287 ],
           [0.5638437 , 0.4361563 ],
           [0.84754217, 0.15245777],
           [0.48752388, 0.5124761 ],
           [0.6018397 , 0.3981603 ],
           [0.5494994 , 0.45050067],
           [0.11785938, 0.88214064],
           [0.27869081, 0.7213092 ],
           [0.56936204, 0.43063793],
           [0.5494047 , 0.45059532],
           [0.5621529 , 0.43784705],
           [0.6220919 , 0.37790808],
           [0.5060851 , 0.49391496],
           [0.59638244, 0.40361756],
           [0.7964352 , 0.20356482],
           [0.7606388 , 0.23936124],
           [0.10248011, 0.89751995],
           [0.78164834, 0.21835163],
           [0.4723103 , 0.5276897 ],
           [0.49407586, 0.5059241 ],
           [0.38122934, 0.61877066],
           [0.38449833, 0.61550164],
           [0.63190067, 0.3680994 ],
           [0.8483737 , 0.15162629],
           [0.45427904, 0.54572093],
           [0.96844727, 0.03155275],
           [0.5165967 , 0.48340335],
           [0.803517  , 0.19648303],
           [0.5907051 , 0.40929496],
           [0.5812092 , 0.4187908 ],
           [0.4962427 , 0.5037573 ],
           [0.947134  , 0.052866  ],
           [0.49460727, 0.5053927 ],
           [0.5569592 , 0.44304082],
           [0.69783175, 0.30216825],
           [0.5194609 , 0.48053908],
           [0.9307156 , 0.06928433],
           [0.6881421 , 0.31185785],
           [0.09061828, 0.9093817 ],
           [0.1444494 , 0.85555065],
           [0.4076562 , 0.5923438 ],
           [0.5594016 , 0.44059846],
           [0.68435806, 0.31564194],
           [0.70819193, 0.291808  ],
           [0.3907266 , 0.60927343],
           [0.6946513 , 0.30534866],
           [0.50326234, 0.49673763],
           [0.51701045, 0.4829896 ],
           [0.899293  , 0.10070696],
           [0.5907886 , 0.4092114 ],
           [0.5607287 , 0.43927127],
           [0.6081303 , 0.39186972],
           [0.5666111 , 0.43338898],
           [0.670015  , 0.32998502],
           [0.82197577, 0.17802422],
           [0.5535489 , 0.44645116],
           [0.78512126, 0.21487866],
           [0.6163605 , 0.38363954],
           [0.5643976 , 0.4356025 ],
           [0.83401   , 0.16598994],
           [0.7271397 , 0.2728603 ],
           [0.63842374, 0.36157623],
           [0.53714156, 0.46285844],
           [0.64335185, 0.35664812],
           [0.41431555, 0.5856845 ],
           [0.8108173 , 0.18918265],
           [0.46940142, 0.5305986 ],
           [0.548841  , 0.45115897],
           [0.06288967, 0.93711036],
           [0.28083804, 0.7191619 ],
           [0.6029498 , 0.39705017],
           [0.6252614 , 0.37473857],
           [0.42861676, 0.57138324],
           [0.6461776 , 0.35382232],
           [0.77439517, 0.22560479],
           [0.65509343, 0.34490648],
           [0.34214535, 0.65785474],
           [0.84118956, 0.1588105 ],
           [0.50138885, 0.49861124],
           [0.54853   , 0.45146996],
           [0.33521992, 0.66478   ],
           [0.8855801 , 0.11441991],
           [0.5509524 , 0.44904763],
           [0.62435764, 0.37564236],
           [0.44735175, 0.5526482 ],
           [0.43819872, 0.5618013 ],
           [0.05801127, 0.9419887 ],
           [0.8757627 , 0.12423727],
           [0.6717561 , 0.32824394],
           [0.3002929 , 0.69970703],
           [0.81870097, 0.18129909],
           [0.35895038, 0.6410496 ],
           [0.5809451 , 0.41905493],
           [0.5689927 , 0.43100736],
           [0.74481016, 0.2551898 ],
           [0.44529307, 0.55470693],
           [0.24422286, 0.7557772 ],
           [0.47098085, 0.52901906],
           [0.5346994 , 0.4653006 ],
           [0.6509696 , 0.34903044],
           [0.74141985, 0.2585802 ],
           [0.03472701, 0.96527296],
           [0.8199905 , 0.18000944],
           [0.50861406, 0.491386  ],
           [0.51787764, 0.4821224 ],
           [0.5663649 , 0.43363518],
           [0.7965462 , 0.20345384],
           [0.7947048 , 0.20529528],
           [0.6044491 , 0.3955509 ],
           [0.5875091 , 0.4124909 ],
           [0.5519187 , 0.4480813 ],
           [0.55839974, 0.4416003 ],
           [0.4389113 , 0.56108874],
           [0.51594645, 0.4840536 ],
           [0.8576415 , 0.14235851],
           [0.540509  , 0.45949098],
           [0.435743  , 0.564257  ],
           [0.59448314, 0.40551683],
           [0.6851735 , 0.31482652],
           [0.5270926 , 0.47290742],
           [0.5498738 , 0.45012623],
           [0.29271808, 0.7072819 ]], dtype=float32)




```python
model.save('cats_and_dogs_2.h5')
```


```python
history.history.keys()
```




    dict_keys(['loss', 'accuracy', 'val_loss', 'val_accuracy'])



Plotting training and validation accuracy and los graphs.


```python
import matplotlib.pyplot as plt
acc = history.history['accuracy']
val_acc = history.history['val_accuracy']
loss = history.history['loss']
val_loss = history.history['val_loss']
epochs = range(1, len(acc) + 1)
plt.plot(epochs, acc, 'bo', label='Training acc')
plt.plot(epochs, val_acc, 'b', label='Validation acc')
plt.title('Training and validation accuracy')
plt.legend()
plt.figure()
plt.plot(epochs, loss, 'bo', label='Training loss')
plt.plot(epochs, val_loss, 'b', label='Validation loss')
plt.title('Training and validation loss')
plt.legend()
plt.show()
```


    
![png](output_114_0.png)
    



    
![png](output_114_1.png)
    



```python
CNN gives us the highest accuracy so far.
```

# Conclusion

So far in this report we explored how to use image classification for classifying an image as Dog or Cat in Machine Learning by implementing common ML algorithms and one deep learning algorithm including Decision Tree, Random Forest, KNN, K-Means, and CNN. K means Classifier shows the best performance with 74% accuracy followed by CNN with 73% accuracy, Random Forest with 64.5% accuracy, Decision Tree with 57% accuracy and KNN with 55% accuracy. Thus, K Means exhibits the best performance and KNN the worst.
